# Oddkin domain icons

128 original outlined SVG icons: **64 GIS** and **64 healthcare**. The existing Core UI icons in Figma are a separate legacy set whose original source is unrecorded.

These new icons follow the existing Oddkin convention: a 20 × 20 coordinate grid, 1.5 px strokes, rounded caps and joins, and no fill. Use the same size within a control. Keep visible labels for unfamiliar domain symbols.

Each SVG inherits `currentColor`; use the relevant Oddkin semantic foreground token in the consuming application. In Figma, the stroke is bound to `Component roles/color/text/primary`, which supports light and dark modes. Each icon is a standalone editable component, available for instance swaps. The dedicated [Icons page](https://www.figma.com/design/E7LfRysny8V3qU24tv082i/Untitled?node-id=359-2) holds labeled Core UI, GIS and Healthcare catalogs, with main components kept separately from the preview instances.

## Files and maintenance

- `gis/` and `healthcare/`: ready-to-use SVG assets.
- `catalog.json`: names, labels, categories, paths and file locations.
- `catalog.mjs`: original artwork source; edit paths here.
- `preview.html`: labeled contact sheets for visual review.
- `generate.mjs`: regenerate assets with `node design/icons/generate.mjs`.

SVGs have an accessible title and image label. When placed beside text that already names the action, mark the SVG `aria-hidden="true"` and remove its image role and label. Icons do not replace a control's accessible name.

The GIS and healthcare artwork is original work created for this repository and is distributed under the repository's [MIT license](../../LICENSE). No third-party icon library was copied or embedded.
