import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { format } from 'prettier';
import { catalog, svgFor } from './catalog.mjs';

const root = new URL('./', import.meta.url);
for (const domain of ['gis', 'healthcare'])
  await mkdir(new URL(`${domain}/`, root), { recursive: true });
for (const icon of catalog) await writeFile(new URL(icon.file, root), svgFor(icon));
await writeFile(
  new URL('catalog.json', root),
  JSON.stringify({ grid: 20, strokeWidth: 1.5, license: 'MIT', icons: catalog }, null, 2) + '\n',
);
const cards = (domain) =>
  catalog
    .filter((icon) => icon.domain === domain)
    .map(
      (icon) =>
        `<article data-domain="${icon.domain}"><div>${svgFor(icon)}</div><b>${icon.label}</b><small>${icon.category}</small></article>`,
    )
    .join('');
const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>Oddkin domain icons</title><style>*{box-sizing:border-box}body{margin:0;background:#f7f6f3;color:#242529;font:14px system-ui;padding:40px}h1{font-size:28px;margin:0 0 8px}p{color:#626472;margin:0 0 32px}.grid{display:grid;grid-template-columns:repeat(8,1fr);gap:16px}article{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:130px;background:white;border:1px solid #dadbe1;border-radius:8px;gap:8px;text-align:center;padding:12px}article div{height:40px;display:flex;align-items:center}svg{width:32px;height:32px}small{color:#626472;font-size:11px}section+section{margin-top:48px}h2{font-size:22px}</style><h1>Oddkin · GIS & healthcare icons</h1><p>Original artwork · 20 px grid · 1.5 px rounded strokes · 64 icons in each set</p>${['gis', 'healthcare'].map((domain) => `<section id="${domain}"><h2>${domain === 'gis' ? 'GIS' : 'Healthcare'}</h2><div class="grid">${cards(domain)}</div></section>`).join('')}</html>`;
await writeFile(new URL('preview.html', root), await format(html, { parser: 'html' }));
console.log(
  `Generated ${catalog.length} SVGs, catalog.json and preview.html in ${fileURLToPath(root)}`,
);
